import { TelFormatPipe } from './tel-format.pipe';

describe('TelFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new TelFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
