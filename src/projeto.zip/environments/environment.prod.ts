export const environment = {
  production: true,
  assets: 'assets/'
};
